Hello there.
To use this marvellous peice of technology just put this on your desktop, then open a command prompt.
Once you have done that use the "cd" command to find your way to the desktop.
Then just type "odd_articles.exe". Once that is done, the program should start.

Here is an example screen:
C:\Users\Columbidae\Desktop\odd_articles>odd_articles.exe
How to: cite half a sentence

Go again?(y/n)

Be careful, typing yes to the question above will not cause another article title to show up. You must type "y".

And if you want this as an app, then you're in luck! Just get it onto your mobile, download a windows VM
or find a exe to apk app, and just to let you know I will never tell you how to do this on IOS because
Iphones are overpriced, then you just run the app.